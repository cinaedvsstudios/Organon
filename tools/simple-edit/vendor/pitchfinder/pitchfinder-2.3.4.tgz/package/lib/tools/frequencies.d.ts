import { PitchDetector } from '../detectors/types';
export declare const DEFAULT_FREQUENCIES_PARAMS: FrequenciesParams;
interface FrequenciesParams {
    tempo: number;
    quantization: number;
    sampleRate: number;
}
export declare function frequencies(detector: PitchDetector | Array<PitchDetector>, float32AudioBuffer: Float32Array, options?: Partial<FrequenciesParams>): Array<number | null>;
export {};
