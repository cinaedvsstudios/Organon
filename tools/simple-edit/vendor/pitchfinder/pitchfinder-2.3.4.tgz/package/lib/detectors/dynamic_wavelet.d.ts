import { PitchDetector } from './types';
export interface DynamicWaveletConfig {
    sampleRate: number;
}
export declare function DynamicWavelet(params?: Partial<DynamicWaveletConfig>): PitchDetector;
