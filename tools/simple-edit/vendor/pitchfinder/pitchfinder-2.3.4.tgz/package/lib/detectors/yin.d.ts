import { PitchDetector } from './types';
export interface YinConfig {
    threshold: number;
    sampleRate: number;
    probabilityThreshold: number;
}
export declare function YIN(params?: Partial<YinConfig>): PitchDetector;
