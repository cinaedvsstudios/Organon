import { ProbabalisticPitchDetector } from './types';
export interface MacleodConfig {
    /**
     * The expected size of an audio buffer (in samples).
     */
    bufferSize: number;
    /**
     * Defines the relative size the chosen peak (pitch) has. 0.93 means: choose
     * the first peak that is higher than 93% of the highest peak detected. 93%
     * is the default value used in the Tartini user interface.
     */
    cutoff: number;
    /**
     * Sample rate
     */
    sampleRate: number;
}
export declare function Macleod(params?: Partial<MacleodConfig>): ProbabalisticPitchDetector;
