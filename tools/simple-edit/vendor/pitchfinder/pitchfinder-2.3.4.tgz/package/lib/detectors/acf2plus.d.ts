import { PitchDetector } from './types';
export interface ACF2Config {
    sampleRate: number;
}
export declare function ACF2PLUS(params?: Partial<ACF2Config>): PitchDetector;
