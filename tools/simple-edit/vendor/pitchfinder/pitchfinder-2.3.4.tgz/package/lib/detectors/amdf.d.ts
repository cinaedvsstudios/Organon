import { PitchDetector } from './types';
export interface AMDFConfig {
    sampleRate: number;
    minFrequency: number;
    maxFrequency: number;
    sensitivity: number;
    ratio: number;
}
export declare function AMDF(params?: Partial<AMDFConfig>): PitchDetector;
